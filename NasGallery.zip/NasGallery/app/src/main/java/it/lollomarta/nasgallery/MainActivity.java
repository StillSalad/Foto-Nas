package it.lollomarta.nasgallery;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    private static final String DEFAULT_URL = "http://192.168.1.57:8100";
    private WebView web;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private FrameLayout root;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void changeUrl() { runOnUiThread(MainActivity.this::askUrl); }
            @JavascriptInterface public void retry() { runOnUiThread(MainActivity.this::load); }
        }, "App");

        web.setWebViewClient(new WebViewClient() {
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    v.loadDataWithBaseURL(null,
                        "<body style='background:#111;color:#eee;font-family:sans-serif;text-align:center;padding:40px'>"
                        + "<h2>NAS non raggiungibile</h2><p>Sei connesso al Wi-Fi di casa?<br>" + getUrl() + "</p>"
                        + "<p><button style='font-size:18px;padding:12px 24px' onclick='App.retry()'>Riprova</button></p>"
                        + "<p><button style='font-size:18px;padding:12px 24px' onclick='App.changeUrl()'>Cambia indirizzo</button></p></body>",
                        "text/html", "utf-8", null);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View v, CustomViewCallback cb) {
                customView = v; customCallback = cb;
                root.addView(v, new FrameLayout.LayoutParams(-1, -1));
                web.setVisibility(View.GONE);
            }
            @Override public void onHideCustomView() {
                if (customView != null) { root.removeView(customView); customView = null; customCallback.onCustomViewHidden(); }
                web.setVisibility(View.VISIBLE);
            }
        });
        if (b != null) web.restoreState(b); else load();
    }

    private SharedPreferences prefs() { return getSharedPreferences("nas", Context.MODE_PRIVATE); }
    private String getUrl() { return prefs().getString("url", DEFAULT_URL); }
    private void load() { web.loadUrl(getUrl()); }

    private void askUrl() {
        final EditText et = new EditText(this);
        et.setText(getUrl());
        et.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        new AlertDialog.Builder(this).setTitle("Indirizzo del NAS").setView(et)
            .setPositiveButton("Salva", (d, w) -> {
                String u = et.getText().toString().trim();
                if (!u.startsWith("http")) u = "http://" + u;
                prefs().edit().putString("url", u).apply();
                load();
            }).setNegativeButton("Annulla", null).show();
    }

    @Override protected void onSaveInstanceState(Bundle o) { super.onSaveInstanceState(o); web.saveState(o); }

    @Override public void onBackPressed() {
        if (customView != null) web.getWebChromeClient().onHideCustomView();
        else if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
